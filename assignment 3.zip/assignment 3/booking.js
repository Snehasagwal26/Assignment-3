// Initialize variables
let costPerDay = 35; // Default rate
let numberOfDaysSelected = 0;
let totalCost = 0;

// Function to update the total cost
function updateTotalCost() {
    totalCost = costPerDay * numberOfDaysSelected;
    document.getElementById("calculated-cost").innerHTML = totalCost;
}

// Function to handle day button click
function handleDayButtonClick(day) {
    if (!day.classList.contains("clicked")) {
        day.classList.add("clicked");
        numberOfDaysSelected++;
        updateTotalCost();
    }
}

// Function to handle clear button click
function handleClearButtonClick() {
    let days = document.querySelectorAll(".day");
    days.forEach(day => {
        day.classList.remove("clicked");
    });
    numberOfDaysSelected = 0;
    totalCost = 0;
    updateTotalCost();
}

// Function to handle half-day button click
function handleHalfDayButtonClick() {
    costPerDay = 20;
    document.getElementById("half").classList.add("clicked");
    document.getElementById("full").classList.remove("clicked");
    updateTotalCost();
}

// Function to handle full-day button click
function handleFullDayButtonClick() {
    costPerDay = 35;
    document.getElementById("full").classList.add("clicked");
    document.getElementById("half").classList.remove("clicked");
    updateTotalCost();
}

// Event listeners
document.querySelectorAll(".day").forEach(day => {
    day.addEventListener("click", () => handleDayButtonClick(day));
});

document.getElementById("clear-button").addEventListener("click", handleClearButtonClick);
document.getElementById("half").addEventListener("click", handleHalfDayButtonClick);
document.getElementById("full").addEventListener("click", handleFullDayButtonClick);
