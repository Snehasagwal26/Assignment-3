// Function to handle submit button click
function handleSubmitButtonClick() {
    // Replace the contents of the contact-page with a single <p> element
    let contactPage = document.getElementById("contact-page");
    contactPage.innerHTML = "<p style='font-size: 24px;'>Thank you for your message</p>";
}

// Event listener for submit button click
document.getElementById("submit-button").addEventListener("click", handleSubmitButtonClick);
